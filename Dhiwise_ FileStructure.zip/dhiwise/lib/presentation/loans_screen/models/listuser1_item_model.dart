import 'package:get/get.dart';

class Listuser1ItemModel {
  Rx<String> loantypeTxt = Rx("Personal Loans");

  Rx<String> priceTxt = Rx("50,000");

  Rx<String>? id = Rx("");
}
