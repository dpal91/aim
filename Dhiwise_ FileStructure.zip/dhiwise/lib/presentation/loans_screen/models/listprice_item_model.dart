import 'package:get/get.dart';

class ListpriceItemModel {
  Rx<String> priceTxt = Rx("100,000");

  Rx<String> priceOneTxt = Rx("40,500");

  Rx<String>? id = Rx("");
}
