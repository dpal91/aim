import 'package:get/get.dart';

class ListlocationItemModel {
  Rx<String> typeTxt = Rx("Life Insurance");

  Rx<String> unlimitedprotectionTxt = Rx("Unlimited protection");

  Rx<String>? id = Rx("");
}
