import 'package:get/get.dart';

class ListquestionItemModel {
  Rx<String> typeTxt = Rx("Business loans");

  Rx<String>? id = Rx("");
}
