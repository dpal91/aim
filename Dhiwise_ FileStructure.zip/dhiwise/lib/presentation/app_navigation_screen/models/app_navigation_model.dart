class AppNavigationModel {}
