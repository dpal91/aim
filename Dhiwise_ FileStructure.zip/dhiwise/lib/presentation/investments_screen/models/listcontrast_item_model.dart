import 'package:get/get.dart';

class ListcontrastItemModel {
  Rx<String> totalInvestedAmountTxt = Rx("Total Invested Amount");

  Rx<String> priceTxt = Rx("150,000");

  Rx<String>? id = Rx("");
}
