import 'package:get/get.dart';

class ListslnoItemModel {
  Rx<String> sLNoTxt = Rx("SL No");

  Rx<String> nameTxt = Rx("Name");

  Rx<String> priceTxt = Rx("Price");

  Rx<String> returnTxt = Rx("Return");

  Rx<String>? id = Rx("");
}
