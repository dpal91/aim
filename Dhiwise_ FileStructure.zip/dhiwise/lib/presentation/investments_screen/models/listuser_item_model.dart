import 'package:get/get.dart';

class ListuserItemModel {
  Rx<String> typeTxt = Rx("Apple Store");

  Rx<String> growthTxt = Rx("+16%");

  Rx<String>? id = Rx("");
}
