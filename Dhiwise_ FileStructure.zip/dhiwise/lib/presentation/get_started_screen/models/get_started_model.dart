class GetStartedModel {}
