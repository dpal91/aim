import 'package:debasish_s_application1/core/app_export.dart';
import 'package:debasish_s_application1/presentation/get_started_screen/models/get_started_model.dart';

class GetStartedController extends GetxController {
  Rx<GetStartedModel> getStartedModelObj = GetStartedModel().obs;
  var data = "hi";

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
