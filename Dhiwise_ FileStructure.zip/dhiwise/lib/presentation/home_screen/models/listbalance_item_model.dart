import 'package:get/get.dart';

class ListbalanceItemModel {
  Rx<String>? id = Rx("");
}
