import 'package:get/get.dart';

class ListvideocameraItemModel {
  Rx<String> depositfrommyTxt = Rx("Deposit from my");

  Rx<String> dateTxt = Rx("28 January 2021");

  Rx<String> priceTxt = Rx("-850");

  Rx<String>? id = Rx("");
}
