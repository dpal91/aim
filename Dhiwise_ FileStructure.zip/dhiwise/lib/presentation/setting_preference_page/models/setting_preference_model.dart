class SettingPreferenceModel {}
