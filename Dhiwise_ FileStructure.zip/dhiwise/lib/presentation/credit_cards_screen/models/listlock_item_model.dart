import 'package:get/get.dart';

class ListlockItemModel {
  Rx<String> changepiccodevalueTxt = Rx("Change Pic Code");

  Rx<String>? id = Rx("");
}
