import 'package:get/get.dart';

class ListellipsethirtythreeItemModel {
  Rx<String> dBLBankTxt = Rx("DBL Bank");

  Rx<String> bRCBankTxt = Rx("BRC Bank");

  Rx<String>? id = Rx("");
}
