import 'package:get/get.dart';

class ListfileItemModel {
  Rx<String> bankvalueTxt = Rx("DBL Bank");

  Rx<String>? id = Rx("");
}
