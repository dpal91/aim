import 'package:get/get.dart';

class Listbalance2ItemModel {
  Rx<String>? id = Rx("");
}
