import 'package:get/get.dart';

class AccountsItemModel {
  Rx<String> myBalanceTxt = Rx("My Balance");

  Rx<String> priceTxt = Rx("12,750");

  Rx<String>? id = Rx("");
}
