import 'package:get/get.dart';

class ListrefreshItemModel {
  Rx<String> storenameTxt = Rx("Apple Store");

  Rx<String> timeagoTxt = Rx("5h ago");

  Rx<String> priceTxt = Rx("450");

  Rx<String>? id = Rx("");
}
