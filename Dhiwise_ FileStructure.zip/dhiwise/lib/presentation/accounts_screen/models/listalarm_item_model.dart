import 'package:get/get.dart';

class ListalarmItemModel {
  Rx<String> subscriptiontypeTxt = Rx("Spotify Subscription");

  Rx<String> priceTxt = Rx("-150");

  Rx<String>? id = Rx("");
}
