import 'package:debasish_s_application1/core/app_export.dart';
import 'package:debasish_s_application1/presentation/side_menu_draweritem/models/side_menu_model.dart';

class SideMenuController extends GetxController {
  Rx<SideMenuModel> sideMenuModelObj = SideMenuModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
