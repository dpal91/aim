class SideMenuModel {}
