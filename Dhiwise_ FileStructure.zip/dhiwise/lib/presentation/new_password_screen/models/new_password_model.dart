class NewPasswordModel {}
