class SettingSecurityModel {}
