import 'package:debasish_s_application1/core/app_export.dart';
import 'package:debasish_s_application1/presentation/get_started_screen/controller/get_started_controller.dart';
import 'package:debasish_s_application1/presentation/splash_screen/models/splash_model.dart';

class SplashController extends GetxController {
  Rx<SplashModel> splashModelObj = SplashModel().obs;
  var data = 'nodata'.obs;

  @override
  void onReady() {
    super.onReady();
    GetStartedController getStartedController = Get.put(GetStartedController());
    data.value = getStartedController.data;
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.offAllNamed(AppRoutes.getStartedScreen);
    });
  }

  @override
  void onClose() {
    super.onClose();
  }
}
