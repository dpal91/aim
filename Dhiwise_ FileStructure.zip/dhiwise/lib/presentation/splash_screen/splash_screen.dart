import 'controller/splash_controller.dart';
import 'package:debasish_s_application1/core/app_export.dart';
import 'package:flutter/material.dart';

class SplashScreen extends GetWidget<SplashController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: ColorConstant.indigo600,
        body: Obx(() => Container(
            width: double.maxFinite,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              GestureDetector(
                onTap: () {
                  controller.data.value = "yes, clicked";
                },
                child: CustomImageView(
                    imagePath: ImageConstant.imgLogo,
                    height: getVerticalSize(58),
                    width: getHorizontalSize(233),
                    margin: getMargin(bottom: 5)),
              ),
              Text(controller.data.value),
            ]))));
  }
}
