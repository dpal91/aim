import 'package:get/get.dart';

class Listbalance1ItemModel {
  Rx<String>? id = Rx("");
}
