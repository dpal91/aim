class ImageConstant {
  static String imgGroup346chart = 'assets/images/img_group346chart.svg';

  static String imgGroup1049 = 'assets/images/img_group1049.svg';

  static String imgUser45x45 = 'assets/images/img_user_45x45.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgFileBlueGray400 = 'assets/images/img_file_blue_gray_400.svg';

  static String imgLogoIndigo600 = 'assets/images/img_logo_indigo_600.png';

  static String imgRefresh = 'assets/images/img_refresh.svg';

  static String imgGroup1032 = 'assets/images/img_group1032.svg';

  static String imgEllipse32WhiteA700 =
      'assets/images/img_ellipse32_white_a700.svg';

  static String imgBag = 'assets/images/img_bag.svg';

  static String imgInfo = 'assets/images/img_info.svg';

  static String imgEllipse1850x503 = 'assets/images/img_ellipse18_50x50_3.png';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgGraph1 = 'assets/images/img_graph1.svg';

  static String imgCheckmarkBlueGray400 =
      'assets/images/img_checkmark_blue_gray_400.svg';

  static String imgSettings21 = 'assets/images/img_settings21.svg';

  static String imgQuestionBlueGray400 =
      'assets/images/img_question_blue_gray_400.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgArrowGreen600 = 'assets/images/img_arrow_green_600.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgReply = 'assets/images/img_reply.svg';

  static String imgArrowrightBlueGray400 =
      'assets/images/img_arrowright_blue_gray_400.svg';

  static String imgArrow = 'assets/images/img_arrow.svg';

  static String imgEllipse3735x35 = 'assets/images/img_ellipse37_35x35.png';

  static String imgGroup1045 = 'assets/images/img_group1045.svg';

  static String imgContrast45x45 = 'assets/images/img_contrast_45x45.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgGroup9320 = 'assets/images/img_group9320.svg';

  static String imgGoogle45x45 = 'assets/images/img_google_45x45.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgLink = 'assets/images/img_link.svg';

  static String imgClock45x45 = 'assets/images/img_clock_45x45.svg';

  static String imgSend = 'assets/images/img_send.svg';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgTicket18x18 = 'assets/images/img_ticket_18x18.svg';

  static String imgEllipse1850x501 = 'assets/images/img_ellipse18_50x50_1.png';

  static String imgLogo = 'assets/images/img_logo.png';

  static String imgGroup438 = 'assets/images/img_group438.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgGroup9321 = 'assets/images/img_group9321.svg';

  static String imgEllipse28170x170 = 'assets/images/img_ellipse28_170x170.png';

  static String imgUserBlueGray400 = 'assets/images/img_user_blue_gray_400.svg';

  static String imgArrowrightIndigo600 =
      'assets/images/img_arrowright_indigo_600.svg';

  static String imgGroup747 = 'assets/images/img_group747.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgGroup9322 = 'assets/images/img_group9322.svg';

  static String imgGroup27 = 'assets/images/img_group27.svg';

  static String imgMap = 'assets/images/img_map.svg';

  static String imgArrowleftIndigo600 =
      'assets/images/img_arrowleft_indigo_600.svg';

  static String imgTransfer1 = 'assets/images/img_transfer1.svg';

  static String imgGroup761 = 'assets/images/img_group761.svg';

  static String imgGoogleBlueA200 = 'assets/images/img_google_blue_a200.svg';

  static String imgBag45x45 = 'assets/images/img_bag_45x45.svg';

  static String imgFloatingicon = 'assets/images/img_floatingicon.svg';

  static String imgAlarm = 'assets/images/img_alarm.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgGroup9319 = 'assets/images/img_group9319.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgEllipse1850x502 = 'assets/images/img_ellipse18_50x50_2.png';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgGroup27Indigo600 =
      'assets/images/img_group27_indigo_600.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgChipcard = 'assets/images/img_chipcard.png';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgService1 = 'assets/images/img_service1.svg';

  static String imgEllipse32 = 'assets/images/img_ellipse32.svg';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgUserBlueGray90001 =
      'assets/images/img_user_blue_gray_900_01.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
